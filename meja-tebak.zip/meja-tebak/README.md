# Meja Tebak

Kumpulan game melatih ingatan dan logika. Game pertama: **Susun Urutan Warna** (100 level).

## Cara main
Susun warna sesuai urutan rahasia. Setelah "Cek susunan", pembawa acara memberi tahu berapa posisi yang sudah benar. Susun ulang sampai semuanya benar.

- Tap warna di meja untuk menaruhnya ke posisi kosong.
- Tap posisi, lalu tap posisi lain untuk menukar. Tap posisi yang sama dua kali untuk mengosongkannya.
- Level 1-29: jumlah warna naik dari 3 sampai 10. Level 30 ke atas: waktu dibatasi dan tebakan terbatas.
- Skor = 1.000 x level + bonus waktu (10 per detik di bawah waktu par) - 50 per tebakan salah.

## Jalankan
```bash
npm install
npm run dev
```

## Unggah ke GitHub dan Vercel (gratis)
```bash
git init && git add . && git commit -m "Meja Tebak"
git branch -M main
git remote add origin https://github.com/USERNAME/meja-tebak.git
git push -u origin main
```
Lalu di vercel.com pilih **Add New > Project**, impor repo ini, klik **Deploy**. Setiap `git push` berikutnya terbit otomatis (paket Hobby gratis).

## Struktur
- `src/game.js` aturan level, skor, penyimpanan progres
- `src/Art.jsx` semua aset SVG (10 item, pembawa acara, pemain)
- `src/Play.jsx` layar permainan
- `src/App.jsx` menu dan peta level
- Semua animasi memakai CSS, tanpa library tambahan.

## Menambah game baru
Tambahkan layar game baru di `src/` dan daftarkan kartunya di menu `App.jsx`. Pakai `calcScore` dan `loadProgress/saveProgress` di `game.js` agar skornya sama.
