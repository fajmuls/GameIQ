export const MAX_LEVEL = 100

// 10 warna, tiap warna punya bentuk sendiri agar mudah dibedakan
export const COLORS = [
  { id: 0, name: 'Merah', fill: '#E63946', shape: 'circle' },
  { id: 1, name: 'Kuning', fill: '#FFC93C', shape: 'star' },
  { id: 2, name: 'Hijau', fill: '#2BB673', shape: 'triangle' },
  { id: 3, name: 'Biru', fill: '#2F80ED', shape: 'square' },
  { id: 4, name: 'Ungu', fill: '#8E5CF5', shape: 'diamond' },
  { id: 5, name: 'Jingga', fill: '#FF8A3D', shape: 'hexagon' },
  { id: 6, name: 'Merah muda', fill: '#FF6FB5', shape: 'heart' },
  { id: 7, name: 'Tosca', fill: '#17BEBB', shape: 'drop' },
  { id: 8, name: 'Cokelat', fill: '#9C6644', shape: 'moon' },
  { id: 9, name: 'Putih', fill: '#F8F9FA', shape: 'cross' },
]

// Level 1-29: jumlah warna naik 3 -> 10. Level 30+: waktu dibatasi dan percobaan terbatas.
export function config(level) {
  const n = Math.min(10, 3 + Math.floor((level - 1) / 4))
  const hard = level > 30
  return {
    n,
    par: 15 + n * 8,
    maxTries: hard ? Math.max(4, 14 - Math.floor((level - 30) / 8)) : Infinity,
    limit: hard ? Math.max(25, Math.round(110 - (level - 30) * 1.2)) : null,
  }
}

export function shuffle(a) {
  const r = [...a]
  for (let i = r.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[r[i], r[j]] = [r[j], r[i]]
  }
  return r
}

export function makeRound(n) {
  const ids = shuffle(COLORS.map((c) => c.id)).slice(0, n)
  return { secret: shuffle(ids), palette: shuffle(ids) }
}

export const countCorrect = (guess, secret) =>
  guess.reduce((s, c, i) => s + (c === secret[i] ? 1 : 0), 0)

// Skor = 1.000 x level + bonus waktu (10 per detik di bawah waktu par) - 50 per tebakan salah
export function calcScore(level, elapsed, wrong, cfg) {
  const base = 1000 * level
  const bonus = Math.max(0, Math.floor(cfg.par - elapsed)) * 10
  const penalty = 50 * wrong
  return { base, bonus, penalty, total: Math.max(0, base + bonus - penalty) }
}

const KEY = 'meja-tebak:urutan-warna'
export function loadProgress() {
  try {
    const p = JSON.parse(localStorage.getItem(KEY))
    if (p && p.unlocked) return p
  } catch (e) { /* abaikan */ }
  return { unlocked: 1, best: {} }
}
export function saveProgress(p) {
  try { localStorage.setItem(KEY, JSON.stringify(p)) } catch (e) { /* abaikan */ }
}
