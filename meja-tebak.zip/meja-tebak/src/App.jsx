import { useState } from 'react'
import Play from './Play.jsx'
import { Host } from './Art.jsx'
import { MAX_LEVEL, config, loadProgress, saveProgress } from './game'

export default function App() {
  const [screen, setScreen] = useState('menu')
  const [level, setLevel] = useState(1)
  const [run, setRun] = useState(0)
  const [prog, setProg] = useState(loadProgress)
  const total = Object.values(prog.best).reduce((a, b) => a + b, 0)

  function onWin(lv, pts) {
    const next = {
      unlocked: Math.min(MAX_LEVEL, Math.max(prog.unlocked, lv + 1)),
      best: { ...prog.best, [lv]: Math.max(prog.best[lv] || 0, pts) },
    }
    setProg(next); saveProgress(next)
  }
  const go = (lv) => { setLevel(lv); setRun((r) => r + 1); setScreen('play') }

  if (screen === 'play') {
    return <Play key={`${level}-${run}`} level={level} onWin={onWin}
      onExit={() => setScreen('map')} onRetry={() => go(level)} onNext={() => go(Math.min(MAX_LEVEL, level + 1))} />
  }

  if (screen === 'map') {
    return (
      <main className="screen">
        <header className="bar">
          <button className="ghost" onClick={() => setScreen('menu')}>Menu</button>
          <strong>Pilih level</strong>
          <span className="chip">{total.toLocaleString('id-ID')}</span>
        </header>
        <div className="levels">
          {Array.from({ length: MAX_LEVEL }, (_, i) => i + 1).map((lv) => {
            const open = lv <= prog.unlocked
            return (
              <button key={lv} disabled={!open} className={`lv ${prog.best[lv] ? 'done' : ''}`} onClick={() => go(lv)}
                aria-label={`Level ${lv}, ${config(lv).n} warna${open ? '' : ', terkunci'}`}>
                {lv}<small>{open ? `${config(lv).n} warna` : 'terkunci'}</small>
              </button>
            )
          })}
        </div>
      </main>
    )
  }

  return (
    <main className="screen menu">
      <Host mood="happy" />
      <h1>Meja Tebak</h1>
      <p className="lead">Latih ingatan dan logikamu dengan menebak susunan.</p>
      <button className="game" onClick={() => setScreen('map')}>
        <b>Susun Urutan Warna</b>
        <span>100 level · skor bonus waktu</span>
      </button>
      <p className="meta">Total skor {total.toLocaleString('id-ID')} · level terbuka {prog.unlocked}/{MAX_LEVEL}</p>
    </main>
  )
}
