import { useEffect, useMemo, useRef, useState } from 'react'
import { COLORS, MAX_LEVEL, config, makeRound, countCorrect, calcScore } from './game'
import { Item, Host, Player } from './Art'

const LINES = {
  start: ['Selamat datang! Susun urutan warnanya, ya.', 'Tebak urutan di balik tirai. Mulai!', 'Tenang, satu per satu saja.'],
  win: ['Tepat sekali! Kamu hebat!', 'Benar semua! Penonton bersorak!'],
  zero: ['Belum ada yang pas. Coba susun ulang!', 'Nol benar, tapi itu juga petunjuk.'],
  some: ['Ada yang pas. Tukar posisi yang lain!', 'Sedikit lagi, pikirkan lagi urutannya.'],
  lose: ['Kesempatan habis. Mau coba lagi?'],
  time: ['Waktu habis! Coba lagi, pasti bisa.'],
}
const pick = (a) => a[Math.floor(Math.random() * a.length)]
const fmt = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`

export default function Play({ level, onWin, onExit, onNext, onRetry }) {
  const cfg = useMemo(() => config(level), [level])
  const round = useMemo(() => makeRound(cfg.n), [cfg])
  const cols = cfg.n > 6 ? Math.ceil(cfg.n / 2) : cfg.n
  const [slots, setSlots] = useState(() => Array(cfg.n).fill(null))
  const [sel, setSel] = useState(null)
  const [tries, setTries] = useState([])
  const [status, setStatus] = useState('play')
  const [elapsed, setElapsed] = useState(0)
  const [mood, setMood] = useState('idle')
  const [line, setLine] = useState(() => pick(LINES.start))
  const [shake, setShake] = useState(false)
  const [result, setResult] = useState(null)
  const start = useRef(Date.now())

  useEffect(() => {
    if (status !== 'play') return
    const t = setInterval(() => {
      const el = (Date.now() - start.current) / 1000
      setElapsed(el)
      if (cfg.limit && el >= cfg.limit) {
        setStatus('timeup'); setMood('sad'); setLine(pick(LINES.time))
      }
    }, 250)
    return () => clearInterval(t)
  }, [status, cfg])

  function pickColor(id) {
    if (status !== 'play' || slots.includes(id)) return
    const next = [...slots]
    const i = sel !== null ? sel : next.indexOf(null)
    if (i < 0) return
    next[i] = id
    setSlots(next); setSel(null); setMood('think')
  }

  function tapSlot(i) {
    if (status !== 'play') return
    if (sel === null) return setSel(i)
    if (sel === i) {
      const next = [...slots]; next[i] = null
      setSlots(next); return setSel(null)
    }
    const next = [...slots]
    ;[next[sel], next[i]] = [next[i], next[sel]]
    setSlots(next); setSel(null)
  }

  function check() {
    if (status !== 'play' || slots.includes(null)) return
    const c = countCorrect(slots, round.secret)
    const t = [...tries, { guess: slots, correct: c }]
    setTries(t); setSel(null)
    if (c === cfg.n) {
      const el = (Date.now() - start.current) / 1000
      const sc = calcScore(level, el, t.length - 1, cfg)
      setElapsed(el); setResult({ ...sc, wrong: t.length - 1, el })
      setStatus('won'); setMood('happy'); setLine(pick(LINES.win))
      onWin(level, sc.total)
    } else if (t.length >= cfg.maxTries) {
      setStatus('lost'); setMood('sad'); setLine(pick(LINES.lose))
    } else {
      setMood('think'); setLine(`Benar ${c} dari ${cfg.n}. ${pick(c === 0 ? LINES.zero : LINES.some)}`)
      setShake(true); setTimeout(() => setShake(false), 450)
    }
  }

  const left = cfg.limit ? Math.max(0, cfg.limit - elapsed) : null
  const full = !slots.includes(null)
  const grid = { gridTemplateColumns: `repeat(${cols}, var(--cell))`, '--cols': cols }

  return (
    <main className="screen play">
      <header className="bar">
        <button className="ghost" onClick={onExit}>Peta level</button>
        <strong>Level {level}</strong>
        <span className="chip" aria-live="off">{left !== null ? `Sisa ${fmt(left)}` : fmt(elapsed)}</span>
      </header>
      {cfg.limit && <div className="meter"><i style={{ width: `${(left / cfg.limit) * 100}%` }} /></div>}

      <section className="stage">
        <Host mood={mood} />
        <p className="bubble" aria-live="polite">{line}</p>
      </section>

      <section className={`table ${shake ? 'shake' : ''}`}>
        <p className="meta">
          {cfg.n} warna · tebakan {tries.length}{cfg.maxTries !== Infinity ? ` dari ${cfg.maxTries}` : ''}
        </p>
        <div className="grid" style={grid}>
          {slots.map((id, i) => (
            <button key={i} className={`slot ${sel === i ? 'on' : ''} ${id !== null ? 'full' : ''}`}
              onClick={() => tapSlot(i)} aria-label={`Posisi ${i + 1}: ${id !== null ? COLORS[id].name : 'kosong'}`}>
              {id !== null ? <Item id={id} /> : <span>{i + 1}</span>}
            </button>
          ))}
        </div>
        <div className="grid tray" style={grid}>
          {round.palette.map((id) => (
            <button key={id} className="pick" disabled={slots.includes(id)} onClick={() => pickColor(id)}
              aria-label={COLORS[id].name}><Item id={id} /></button>
          ))}
        </div>
        <button className="go" disabled={!full || status !== 'play'} onClick={check}>Cek susunan</button>
        <Player mood={mood} />
      </section>

      {tries.length > 0 && (
        <ol className="history" reversed>
          {[...tries].reverse().map((t, k) => (
            <li key={k}>
              <span className="mini">{t.guess.map((id, j) => <Item key={j} id={id} />)}</span>
              <b>{t.correct}/{cfg.n}</b>
            </li>
          ))}
        </ol>
      )}

      {status !== 'play' && (
        <div className="overlay" role="dialog" aria-modal="true">
          {status === 'won' && <div className="confetti" aria-hidden="true">{Array.from({ length: 28 }, (_, i) => (
            <i key={i} style={{ left: `${(i * 37) % 100}%`, background: COLORS[i % 10].fill, animationDelay: `${(i % 7) * 0.12}s` }} />
          ))}</div>}
          <div className="card">
            {status === 'won' ? (
              <>
                <h2>Level {level} selesai!</h2>
                <dl>
                  <dt>Skor dasar</dt><dd>{result.base.toLocaleString('id-ID')}</dd>
                  <dt>Bonus waktu ({fmt(result.el)})</dt><dd>+{result.bonus.toLocaleString('id-ID')}</dd>
                  <dt>{result.wrong} tebakan salah</dt><dd>-{result.penalty.toLocaleString('id-ID')}</dd>
                  <dt>Total</dt><dd className="total">{result.total.toLocaleString('id-ID')}</dd>
                </dl>
                {level < MAX_LEVEL ? <button className="go" onClick={onNext}>Level berikutnya</button>
                  : <p>Kamu menamatkan semua level!</p>}
              </>
            ) : (
              <>
                <h2>{status === 'timeup' ? 'Waktu habis' : 'Kesempatan habis'}</h2>
                <p>Susunan yang benar:</p>
                <div className="mini big">{round.secret.map((id, j) => <Item key={j} id={id} />)}</div>
              </>
            )}
            <button className="ghost" onClick={onRetry}>Ulangi level</button>
            <button className="ghost" onClick={onExit}>Peta level</button>
          </div>
        </div>
      )}
    </main>
  )
}
