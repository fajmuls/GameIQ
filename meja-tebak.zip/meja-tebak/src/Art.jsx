import { COLORS } from './game'

const SHAPES = {
  circle: <circle cx="50" cy="50" r="40" />,
  star: <polygon points="50,8 61,38 93,38 67,57 77,88 50,69 23,88 33,57 7,38 39,38" />,
  triangle: <polygon points="50,10 92,86 8,86" />,
  square: <rect x="14" y="14" width="72" height="72" rx="14" />,
  diamond: <polygon points="50,6 92,50 50,94 8,50" />,
  hexagon: <polygon points="50,8 88,29 88,71 50,92 12,71 12,29" />,
  heart: <path d="M50 88 C10 58 6 30 28 20 C40 15 50 24 50 32 C50 24 60 15 72 20 C94 30 90 58 50 88Z" />,
  drop: <path d="M50 8 C50 8 16 46 16 64 A34 34 0 0 0 84 64 C84 46 50 8 50 8Z" />,
  moon: <path d="M62 10 A40 40 0 1 0 90 66 A32 32 0 1 1 62 10Z" />,
  cross: <polygon points="38,10 62,10 62,38 90,38 90,62 62,62 62,90 38,90 38,62 10,62 10,38 38,38" />,
}

export function Item({ id }) {
  const c = COLORS[id]
  return (
    <svg className="item" viewBox="0 0 100 100" aria-hidden="true">
      <g fill={c.fill} stroke="rgba(30,15,60,.4)" strokeWidth="4" strokeLinejoin="round">{SHAPES[c.shape]}</g>
      <ellipse cx="38" cy="32" rx="12" ry="6" fill="#fff" opacity=".35" transform="rotate(-30 38 32)" />
    </svg>
  )
}

const MOUTH = {
  idle: 'M48 80 Q60 88 72 80',
  happy: 'M44 77 Q60 98 76 77Z',
  sad: 'M48 88 Q60 77 72 88',
  think: 'M52 84 L70 82',
}

export function Host({ mood = 'idle' }) {
  return (
    <svg className={`host ${mood}`} viewBox="0 0 120 150" role="img" aria-label="Pembawa acara">
      <path d="M14 150 Q16 106 60 106 Q104 106 106 150Z" fill="#3B2A6B" />
      <path d="M60 106 L47 124 L60 150 L73 124Z" fill="#FFF4DC" />
      <path d="M48 110 L60 117 L72 110 L72 124 L60 117 L48 124Z" fill="#E63946" />
      <circle cx="60" cy="74" r="28" fill="#F3C29B" />
      <rect x="38" y="12" width="44" height="30" rx="5" fill="#2A1B52" />
      <rect x="38" y="32" width="44" height="7" fill="#F2B544" />
      <rect x="27" y="40" width="66" height="9" rx="4.5" fill="#2A1B52" />
      <circle cx="49" cy="68" r="3.6" fill="#2A1B52" />
      <circle cx="71" cy="68" r="3.6" fill="#2A1B52" />
      {mood === 'sad' && <path d="M43 60 L55 63 M77 60 L65 63" stroke="#2A1B52" strokeWidth="3" strokeLinecap="round" />}
      <circle cx="42" cy="78" r="5" fill="#FF8A8A" opacity=".5" />
      <circle cx="78" cy="78" r="5" fill="#FF8A8A" opacity=".5" />
      <path d={MOUTH[mood]} fill={mood === 'happy' ? '#B23A48' : 'none'} stroke="#2A1B52" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

export function Player({ mood = 'idle' }) {
  return (
    <svg className={`player ${mood}`} viewBox="0 0 100 100" role="img" aria-label="Kamu">
      <path d="M10 100 Q12 66 50 66 Q88 66 90 100Z" fill="#2F80ED" />
      <circle cx="50" cy="44" r="24" fill="#E8B48A" />
      <path d="M26 42 Q28 14 50 14 Q72 14 74 42 Q60 30 26 42Z" fill="#2A1B52" />
      <circle cx="42" cy="46" r="3" fill="#2A1B52" />
      <circle cx="58" cy="46" r="3" fill="#2A1B52" />
      <path d={mood === 'sad' ? 'M42 58 Q50 52 58 58' : 'M40 54 Q50 64 60 54'} fill="none" stroke="#2A1B52" strokeWidth="3" strokeLinecap="round" />
    </svg>
  )
}
